Name: Quan Hoang Dinh

The main code to run in the terminal is Game.java

Inputted as instructed by the code. My code can catches illegal move such as removing
no pieces or removing more than existed pieces. However, it cannot detect errors that
violates the instructions, such as inputting wrong color initial or a character in place
of an integer. In that case, the code will crash.
For a smooth experience, inputted as instructed by the code.

Source: the answer to 1 were research that I found online through the Wiki. The code itself
are all of my original work.